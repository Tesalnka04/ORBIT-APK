package com.practice.poolhud

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.io.ByteArrayOutputStream

class OverlayCaptureService : Service() {
    private lateinit var windowManager: WindowManager
    private lateinit var canvasWebView: WebView
    private lateinit var dockWebView: WebView
    private lateinit var canvasParams: WindowManager.LayoutParams
    private lateinit var dockParams: WindowManager.LayoutParams

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var lastFrameMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        setupDualOverlayWindows()
    }

    private fun startForegroundNotification() {
        val channelId = "pool_hud_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(channelId, "Pool Practice HUD", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(chan)
        }
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("Pool Practice HUD v3.1 Aktif")
            .setContentText("Overlay garis prediksi solid aktif")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        startForeground(101, notif)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun setupDualOverlayWindows() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        canvasWebView = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(CanvasBridge(), "NativeBridge")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    evaluateJavascript("window.AndroidHUD && window.AndroidHUD.initCanvasWindow();", null)
                }
            }
            loadUrl("file:///android_asset/hud.html")
        }

        canvasParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(canvasWebView, canvasParams)

        dockWebView = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(DockBridge(), "NativeBridge")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    evaluateJavascript("window.AndroidHUD && window.AndroidHUD.initDockWindow();", null)
                }
            }
            loadUrl("file:///android_asset/hud.html")
        }

        dockParams = WindowManager.LayoutParams(
            dp(252),
            dp(236),
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(112)
            y = dp(8)
        }
        windowManager.addView(dockWebView, dockParams)
    }

    inner class CanvasBridge {
        @JavascriptInterface
        fun onHudConfigChanged(json: String) {
            val escaped = JSONObject.quote(json)
            dockWebView.post {
                dockWebView.evaluateJavascript("window.AndroidHUD && window.AndroidHUD.applyConfigJson($escaped);", null)
            }
            updateCanvasTouchableFromJson(json)
        }

        @JavascriptInterface
        fun onStatusUpdate(status: String) {
            val escaped = JSONObject.quote(status)
            dockWebView.post {
                dockWebView.evaluateJavascript("window.AndroidHUD && window.AndroidHUD.updateStatusText($escaped);", null)
            }
        }
    }

    inner class DockBridge {
        @JavascriptInterface
        fun onHudConfigChanged(json: String) {
            val escaped = JSONObject.quote(json)
            canvasWebView.post {
                canvasWebView.evaluateJavascript("window.AndroidHUD && window.AndroidHUD.applyConfigJson($escaped);", null)
            }
            updateCanvasTouchableFromJson(json)
        }

        @JavascriptInterface
        fun onDockMinimized(minimized: Boolean) {
            dockWebView.post {
                dockParams.width = if (minimized) dp(156) else dp(252)
                dockParams.height = if (minimized) dp(42) else dp(236)
                windowManager.updateViewLayout(dockWebView, dockParams)
            }
        }

        @JavascriptInterface
        fun moveDockBy(dx: Int, dy: Int) {
            dockWebView.post {
                dockParams.x += dx
                dockParams.y += dy
                windowManager.updateViewLayout(dockWebView, dockParams)
            }
        }
    }

    private fun updateCanvasTouchableFromJson(json: String) {
        try {
            val tapMode = JSONObject(json).optString("tapMode", "")
            val needsTouch = tapMode.isNotEmpty() && tapMode != "null"
            canvasWebView.post {
                if (needsTouch) {
                    canvasParams.flags = canvasParams.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                } else {
                    canvasParams.flags = canvasParams.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                }
                windowManager.updateViewLayout(canvasWebView, canvasParams)
            }
        } catch (_: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data: Intent = intent.getParcelableExtra("DATA") ?: return START_NOT_STICKY
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mgr.getMediaProjection(code, data)
        startScreenCapture()
        return START_STICKY
    }

    private fun startScreenCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        val capW = 640
        val capH = (capW * (metrics.heightPixels.toFloat() / metrics.widthPixels.toFloat())).toInt().coerceAtLeast(360)

        imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "PoolHUDCapture", capW, capH, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, Handler(Looper.getMainLooper())
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            val now = SystemClock.uptimeMillis()
            if (now - lastFrameMs < 65L) {
                img.close()
                return@setOnImageAvailableListener
            }
            lastFrameMs = now

            try {
                val plane = img.planes[0]
                val rowStride = plane.rowStride
                val pixelStride = plane.pixelStride
                val rowPadding = rowStride - pixelStride * capW
                val bmp = Bitmap.createBitmap(capW + rowPadding / pixelStride, capH, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(plane.buffer)
                val cropped = Bitmap.createBitmap(bmp, 0, 0, capW, capH)
                bmp.recycle()

                val baos = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, 65, baos)
                cropped.recycle()
                val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)

                canvasWebView.post {
                    canvasWebView.evaluateJavascript("window.AndroidHUD && window.AndroidHUD.pushNativeFrameBase64('$b64');", null)
                }
            } finally {
                img.close()
            }
        }, Handler(Looper.getMainLooper()))
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
        if (::canvasWebView.isInitialized) windowManager.removeView(canvasWebView)
        if (::dockWebView.isInitialized) windowManager.removeView(dockWebView)
    }
}
