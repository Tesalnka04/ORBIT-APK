package com.practice.poolhud

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val REQ_OVERLAY = 1001
    private val REQ_CAPTURE = 1002
    private lateinit var projectionMgr: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionMgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 80, 48, 48)
            setBackgroundColor(0xFF0B1220.toInt())
        }

        val title = TextView(this).apply {
            text = "Pool Practice Overlay HUD v3.1"
            textSize = 22f
            setTextColor(0xFF42D392.toInt())
        }

        val desc = TextView(this).apply {
            text = "\n1. Izinkan 'Tampilkan di atas aplikasi lain'\n2. Tekan 'Mulai Overlay HUD' & izinkan rekam layar\n3. Buka 8 Ball Pool: semua garis prediksi lurus tegas (solid) & Power/Spin terdeteksi otomatis.\n"
            textSize = 14f
            setTextColor(0xFFEDF4FF.toInt())
        }

        val btnStart = Button(this).apply {
            text = "Mulai Overlay HUD"
            setOnClickListener { checkPermissionsAndStart() }
        }

        val btnStop = Button(this).apply {
            text = "Hentikan Overlay"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayCaptureService::class.java))
                Toast.makeText(this@MainActivity, "Overlay dihentikan", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(btnStart)
        layout.addView(btnStop)
        setContentView(layout)
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivityForResult(intent, REQ_OVERLAY)
            return
        }
        startActivityForResult(projectionMgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            startActivityForResult(projectionMgr.createScreenCaptureIntent(), REQ_CAPTURE)
        } else if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val svcIntent = Intent(this, OverlayCaptureService::class.java).apply {
                putExtra("RESULT_CODE", resultCode)
                putExtra("DATA", data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svcIntent)
            } else {
                startService(svcIntent)
            }
            Toast.makeText(this, "HUD v3.1 Aktif! Buka 8 Ball Pool", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
