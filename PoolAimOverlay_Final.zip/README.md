# Pool Aim Assist Overlay (Android Native)

Aplikasi overlay pendamping transparan (tanpa modifikasi APK 8 Ball Pool ori).

## Fitur Utama
1. **100% Transparent Pass-Through Canvas:** Layar tidak gelap dan sentuhan langsung tembus ke game.
2. **Collapsible Floating Icon (`🎱`):**
   - Kondisi default terlipat jadi 1 ikon bulat kecil yang bisa digeser bebas ke pojok layar.
   - Tap ikon `🎱` untuk **Unhide / Hide** panel setting (`Aim ON/OFF`, `Pantul 1x/3x/4x`, `Meja ON/OFF`, `Kalibrasi Meja -/+`, dan tombol `Hide`).
3. **Sub-Pixel Aim Tracking & Multi-Bounce Physics:**
   - Otomatis membaca arah garis bidik putih bawaan game dengan presisi `0.1°`.
   - Menghitung pantulan multi-cushion, tangent cue ball, combo shot antar bola, dan highlight lingkaran hijau saat garis masuk ke lubang.

## Cara Build APK dari HP via GitHub Actions
1. Upload seluruh isi folder project ini ke repository GitHub baru (branch `main`).
2. Buka tab **Actions** -> pilih workflow **Build Android APK** -> tunggu selesai (±2 menit).
3. Download artifact **`PoolAimAssist-Final-debug`**, ekstrak ZIP-nya, lalu install `app-debug.apk` di HP Android lu.
