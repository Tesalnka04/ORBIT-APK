package com.orbit.pooloverlay

import android.graphics.Color
import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.*

data class DetectedBall(
    val id: Int,
    val center: PointF,
    val radius: Float,
    val color: Int,
    val isCueBall: Boolean = false
)

data class TrajectoryPath(
    val points: List<PointF>,
    val color: Int,
    val endPocketHit: PointF? = null,
    val isCuePath: Boolean = false
)

class PhysicsEngine(
    var tableBounds: RectF,
    var ballRadius: Float = tableBounds.height() / 19.1f / 2f
) {
    fun getPockets(): List<PointF> {
        val l = tableBounds.left
        val r = tableBounds.right
        val t = tableBounds.top
        val b = tableBounds.bottom
        val mx = (l + r) / 2f
        return listOf(
            PointF(l, t), PointF(mx, t), PointF(r, t),
            PointF(l, b), PointF(mx, b), PointF(r, b)
        )
    }

    fun calculateShot(
        cueBall: DetectedBall,
        aimAngleRad: Float,
        balls: List<DetectedBall>,
        maxCueBounces: Int = 3,
        maxTargetBounces: Int = 3
    ): List<TrajectoryPath> {
        val results = mutableListOf<TrajectoryPath>()
        val cuePoints = mutableListOf(PointF(cueBall.center.x, cueBall.center.y))
        val pockets = getPockets()

        var curPos = PointF(cueBall.center.x, cueBall.center.y)
        var dirX = cos(aimAngleRad)
        var dirY = sin(aimAngleRad)

        val minX = tableBounds.left + ballRadius
        val maxX = tableBounds.right - ballRadius
        val minY = tableBounds.top + ballRadius
        val maxY = tableBounds.bottom - ballRadius

        for (step in 0 until maxCueBounces) {
            val tX = if (dirX > 1e-5f) (maxX - curPos.x) / dirX else if (dirX < -1e-5f) (minX - curPos.x) / dirX else Float.MAX_VALUE
            val tY = if (dirY > 1e-5f) (maxY - curPos.y) / dirY else if (dirY < -1e-5f) (minY - curPos.y) / dirY else Float.MAX_VALUE
            var minT = min(tX, tY)
            var hitBall: DetectedBall? = null

            for (target in balls) {
                if (target.isCueBall) continue
                val tHit = rayCircleIntersect(curPos, dirX, dirY, target.center, ballRadius * 2f)
                if (tHit != null && tHit > 1f && tHit < minT) {
                    minT = tHit
                    hitBall = target
                }
            }

            val nextPos = PointF(curPos.x + dirX * minT, curPos.y + dirY * minT)
            cuePoints.add(nextPos)

            val cuePocket = pockets.firstOrNull { hypot(it.x - nextPos.x, it.y - nextPos.y) < ballRadius * 1.9f }
            if (cuePocket != null && hitBall == null) {
                results.add(TrajectoryPath(cuePoints, Color.parseColor("#FF1744"), cuePocket, isCuePath = true))
                return results
            }

            if (hitBall != null) {
                val dx = hitBall.center.x - nextPos.x
                val dy = hitBall.center.y - nextPos.y
                val targetAngle = atan2(dy, dx)

                traceTargetChain(hitBall, targetAngle, balls, maxTargetBounces, results, depth = 0)

                val cross = dirX * dy - dirY * dx
                val tangentAngle = targetAngle + (if (cross > 0f) -PI.toFloat() / 2f else PI.toFloat() / 2f)
                val cutFactor = abs(sin(targetAngle - atan2(dirY, dirX))).coerceIn(0.15f, 1.0f)
                val deflLen = 190f * cutFactor
                val deflEnd = traceSimpleRay(nextPos, cos(tangentAngle), sin(tangentAngle), deflLen)
                cuePoints.add(deflEnd)
                break
            } else {
                if (tX < tY) dirX = -dirX * 0.975f else dirY = -dirY * 0.975f
                curPos = nextPos
            }
        }

        results.add(0, TrajectoryPath(cuePoints, Color.WHITE, isCuePath = true))
        return results
    }

    private fun traceTargetChain(
        ball: DetectedBall,
        angleRad: Float,
        allBalls: List<DetectedBall>,
        maxBounces: Int,
        outPaths: MutableList<TrajectoryPath>,
        depth: Int
    ) {
        if (depth > 2) return
        val pts = mutableListOf(PointF(ball.center.x, ball.center.y))
        var cur = PointF(ball.center.x, ball.center.y)
        var dx = cos(angleRad)
        var dy = sin(angleRad)
        val pockets = getPockets()
        var pocketHit: PointF? = null

        val minX = tableBounds.left + ballRadius
        val maxX = tableBounds.right - ballRadius
        val minY = tableBounds.top + ballRadius
        val maxY = tableBounds.bottom - ballRadius

        for (i in 0 until maxBounces) {
            val tX = if (dx > 1e-5f) (maxX - cur.x) / dx else if (dx < -1e-5f) (minX - cur.x) / dx else Float.MAX_VALUE
            val tY = if (dy > 1e-5f) (maxY - cur.y) / dy else if (dy < -1e-5f) (minY - cur.y) / dy else Float.MAX_VALUE
            var stepT = min(tX, tY)
            var secondaryBall: DetectedBall? = null

            for (other in allBalls) {
                if (other.id == ball.id || other.isCueBall) continue
                val tHit = rayCircleIntersect(cur, dx, dy, other.center, ballRadius * 2f)
                if (tHit != null && tHit > 1f && tHit < stepT) {
                    stepT = tHit
                    secondaryBall = other
                }
            }

            val next = PointF(cur.x + dx * stepT, cur.y + dy * stepT)
            pts.add(next)

            val nearPocket = pockets.firstOrNull { hypot(it.x - next.x, it.y - next.y) < ballRadius * 2.15f }
            if (nearPocket != null) {
                pts.add(nearPocket)
                pocketHit = nearPocket
                break
            }

            if (secondaryBall != null) {
                val comboAngle = atan2(secondaryBall.center.y - next.y, secondaryBall.center.x - next.x)
                traceTargetChain(secondaryBall, comboAngle, allBalls, maxBounces = 2, outPaths = outPaths, depth = depth + 1)
                break
            }

            if (tX < tY) dx = -dx * 0.965f else dy = -dy * 0.965f
            cur = next
        }
        outPaths.add(TrajectoryPath(pts, ball.color, pocketHit, isCuePath = false))
    }

    private fun traceSimpleRay(start: PointF, dx: Float, dy: Float, length: Float): PointF {
        val minX = tableBounds.left + ballRadius
        val maxX = tableBounds.right - ballRadius
        val minY = tableBounds.top + ballRadius
        val maxY = tableBounds.bottom - ballRadius
        val nx = (start.x + dx * length).coerceIn(minX, maxX)
        val ny = (start.y + dy * length).coerceIn(minY, maxY)
        return PointF(nx, ny)
    }

    private fun rayCircleIntersect(
        origin: PointF, dx: Float, dy: Float, center: PointF, combinedRadius: Float
    ): Float? {
        val ocX = origin.x - center.x
        val ocY = origin.y - center.y
        val b = 2f * (ocX * dx + ocY * dy)
        val c = (ocX * ocX + ocY * ocY) - (combinedRadius * combinedRadius)
        val disc = b * b - 4f * c
        if (disc < 0f) return null
        val t = (-b - sqrt(disc)) / 2f
        return if (t > 0f) t else null
    }
}
