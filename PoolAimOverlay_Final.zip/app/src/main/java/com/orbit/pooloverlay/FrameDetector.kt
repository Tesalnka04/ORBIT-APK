package com.orbit.pooloverlay

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.*

object FrameDetector {

    var offsetLeft = 0f
    var offsetTop = 0f
    var offsetRight = 0f
    var offsetBottom = 0f

    fun detectTableBounds(bmp: Bitmap): RectF {
        val w = bmp.width.toFloat()
        val h = bmp.height.toFloat()
        val tableH = h * 0.695f
        val tableW = tableH * 2.0f
        val centerX = w * 0.50f
        val centerY = h * 0.535f
        return RectF(
            (centerX - tableW / 2f) + offsetLeft,
            (centerY - tableH / 2f) + offsetTop,
            (centerX + tableW / 2f) + offsetRight,
            (centerY + tableH / 2f) + offsetBottom
        )
    }

    fun detectBalls(bmp: Bitmap, table: RectF): List<DetectedBall> {
        val detected = mutableListOf<DetectedBall>()
        val ballRadius = (table.height() / 19.1f) / 2f
        val cellSize = (ballRadius * 1.45f).toInt().coerceAtLeast(14)
        val step = (ballRadius / 3.5f).toInt().coerceAtLeast(4)
        val visited = HashSet<Int>()

        val startX = (table.left + ballRadius).toInt().coerceIn(0, bmp.width - 1)
        val endX = (table.right - ballRadius).toInt().coerceIn(0, bmp.width - 1)
        val startY = (table.top + ballRadius).toInt().coerceIn(0, bmp.height - 1)
        val endY = (table.bottom - ballRadius).toInt().coerceIn(0, bmp.height - 1)

        val feltColor = bmp.getPixel(
            table.centerX().toInt().coerceIn(0, bmp.width - 1),
            (table.top + ballRadius * 2f).toInt().coerceIn(0, bmp.height - 1)
        )

        for (y in startY until endY step step) {
            for (x in startX until endX step step) {
                val px = bmp.getPixel(x, y)
                if (colorDistance(px, feltColor) < 48) continue

                val key = (x / cellSize) * 1000 + (y / cellSize)
                if (visited.contains(key)) continue
                visited.add(key)

                var sumX = 0f
                var sumY = 0f
                var count = 0
                var whitePixels = 0
                var dominantColor = px
                var maxSaturation = -1f
                val hsv = FloatArray(3)

                val scanR = ballRadius.toInt()
                for (dy in -scanR..scanR step 3) {
                    for (dx in -scanR..scanR step 3) {
                        val sx = x + dx
                        val sy = y + dy
                        if (sx !in startX until endX || sy !in startY until endY) continue
                        val spx = bmp.getPixel(sx, sy)
                        if (colorDistance(spx, feltColor) >= 48) {
                            sumX += sx
                            sumY += sy
                            count++
                            val r = Color.red(spx)
                            val g = Color.green(spx)
                            val b = Color.blue(spx)
                            if (r > 225 && g > 225 && b > 225) whitePixels++
                            Color.colorToHSV(spx, hsv)
                            if (hsv[1] > maxSaturation && hsv[2] > 0.35f) {
                                maxSaturation = hsv[1]
                                dominantColor = spx
                            }
                        }
                    }
                }

                if (count < 6) continue
                val cx = sumX / count
                val cy = sumY / count
                val isCue = whitePixels.toFloat() / count.toFloat() > 0.58f

                detected.add(
                    DetectedBall(
                        id = detected.size,
                        center = PointF(cx, cy),
                        radius = ballRadius,
                        color = if (isCue) Color.WHITE else brightVividColor(dominantColor),
                        isCueBall = isCue
                    )
                )
            }
        }
        return detected
    }

    fun detectGameAimLineAngle(bmp: Bitmap, cueBall: DetectedBall): Float? {
        val rMin = (cueBall.radius * 1.45f).toInt()
        val rMax = (cueBall.radius * 5.2f).toInt()
        var bestRoughDeg = -1
        var maxScore = 0

        for (deg in 0 until 360) {
            val rad = Math.toRadians(deg.toDouble())
            val score = scoreRayWhiteness(bmp, cueBall.center, rad, rMin, rMax)
            if (score > maxScore) {
                maxScore = score
                bestRoughDeg = deg
            }
        }
        if (maxScore < 6 || bestRoughDeg < 0) return null

        var bestFineRad = Math.toRadians(bestRoughDeg.toDouble())
        var bestFineScore = maxScore
        var d = bestRoughDeg - 1.5
        while (d <= bestRoughDeg + 1.5) {
            val rad = Math.toRadians(d)
            val score = scoreRayWhiteness(bmp, cueBall.center, rad, rMin, rMax)
            if (score > bestFineScore) {
                bestFineScore = score
                bestFineRad = rad
            }
            d += 0.1
        }
        return bestFineRad.toFloat()
    }

    private fun scoreRayWhiteness(
        bmp: Bitmap,
        origin: PointF,
        rad: Double,
        rMin: Int,
        rMax: Int
    ): Int {
        var hits = 0
        val cosA = cos(rad)
        val sinA = sin(rad)
        for (r in rMin..rMax step 3) {
            val sx = (origin.x + cosA * r).toInt()
            val sy = (origin.y + sinA * r).toInt()
            if (sx !in 0 until bmp.width || sy !in 0 until bmp.height) break
            val px = bmp.getPixel(sx, sy)
            if (Color.red(px) > 232 && Color.green(px) > 232 && Color.blue(px) > 232) {
                hits++
            }
        }
        return hits
    }

    private fun brightVividColor(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        if (hsv[1] < 0.25f && hsv[2] < 0.35f) {
            return Color.parseColor("#E040FB")
        }
        hsv[1] = max(hsv[1], 0.85f)
        hsv[2] = max(hsv[2], 0.95f)
        return Color.HSVToColor(hsv)
    }

    private fun colorDistance(c1: Int, c2: Int): Int {
        val dr = Color.red(c1) - Color.red(c2)
        val dg = Color.green(c1) - Color.green(c2)
        val db = Color.blue(c1) - Color.blue(c2)
        return sqrt((dr * dr + dg * dg + db * db).toDouble()).toInt()
    }
}
