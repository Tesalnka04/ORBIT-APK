package com.orbit.pooloverlay

import android.content.Context
import android.graphics.*
import android.view.View

class AimOverlayView(context: Context) : View(context) {

    var tableRect = RectF(260f, 155f, 2140f, 955f)
    var trajectories: List<TrajectoryPath> = emptyList()
    var pocketPositions: List<PointF> = emptyList()
    var showTableFrame = true
    var showBounceLines = true

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.argb(120, 0, 230, 118)
    }

    private val lineOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6.5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.argb(180, 0, 0, 0)
    }

    private val lineFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.8f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val pocketRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.argb(170, 0, 230, 118)
    }

    private val pocketHitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 7f
        color = Color.parseColor("#00E676")
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.TRANSPARENT)

        if (showTableFrame) {
            canvas.drawRect(tableRect, borderPaint)
            for (p in pocketPositions) {
                canvas.drawCircle(p.x, p.y, 28f, pocketRingPaint)
            }
        }

        for (traj in trajectories) {
            if (traj.points.size < 2) continue
            val limitIndex = if (showBounceLines) traj.points.size else 2
            val path = Path().apply {
                moveTo(traj.points[0].x, traj.points[0].y)
                for (i in 1 until limitIndex) {
                    lineTo(traj.points[i].x, traj.points[i].y)
                }
            }
            canvas.drawPath(path, lineOutlinePaint)
            lineFillPaint.color = traj.color
            canvas.drawPath(path, lineFillPaint)

            val endPt = traj.points[limitIndex - 1]
            canvas.drawCircle(endPt.x, endPt.y, 16f, lineOutlinePaint)
            canvas.drawCircle(endPt.x, endPt.y, 16f, lineFillPaint)

            if (showBounceLines) {
                traj.endPocketHit?.let { hit ->
                    canvas.drawCircle(hit.x, hit.y, 34f, pocketHitPaint)
                }
            }
        }
    }
}
