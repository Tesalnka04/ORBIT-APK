package com.orbit.pooloverlay

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayTrackingService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: AimOverlayView
    private lateinit var floatingDock: LinearLayout
    private lateinit var menuPanel: LinearLayout
    private lateinit var toggleIconBtn: TextView

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var isTrackingEnabled = true
    private var isMenuExpanded = false
    private var maxBounces = 3

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()
        setupTransparentOverlay()
        setupCollapsibleFloatingMenu()

        val resultCode = intent?.getIntExtra("RESULT_CODE", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("DATA")
        if (resultCode == Activity.RESULT_OK && data != null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(resultCode, data)
            startScreenCapture()
        }
        return START_STICKY
    }

    private fun getOverlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun setupTransparentOverlay() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlayView = AimOverlayView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            getOverlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        windowManager.addView(overlayView, params)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupCollapsibleFloatingMenu() {
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        floatingDock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val iconBg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E53935"))
            setStroke(dp(2), Color.WHITE)
        }

        toggleIconBtn = TextView(this).apply {
            text = "🎱"
            textSize = 16f
            gravity = Gravity.CENTER
            background = iconBg
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        }

        val panelBg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.argb(215, 18, 22, 30))
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }

        menuPanel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = panelBg
            setPadding(dp(8), dp(4), dp(8), dp(4))
            visibility = View.GONE
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginStart = dp(6)
            layoutParams = lp
        }

        fun makeChip(label: String, activeColor: String = "#00C853", onClick: (TextView) -> Unit): TextView {
            val chipBg = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.parseColor(activeColor))
            }
            return TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                typeface = Typeface.DEFAULT_BOLD
                background = chipBg
                setPadding(dp(10), dp(6), dp(10), dp(6))
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = dp(5)
                layoutParams = lp
                setOnClickListener { onClick(this) }
            }
        }

        val btnAim = makeChip("Aim: ON", "#00C853") { btn ->
            isTrackingEnabled = !isTrackingEnabled
            overlayView.visibility = if (isTrackingEnabled) View.VISIBLE else View.GONE
            btn.text = if (isTrackingEnabled) "Aim: ON" else "Aim: OFF"
            (btn.background as GradientDrawable).setColor(
                Color.parseColor(if (isTrackingEnabled) "#00C853" else "#455A64")
            )
        }

        val btnBounce = makeChip("Pantul: 3x", "#1E88E5") { btn ->
            maxBounces = when (maxBounces) {
                3 -> 1
                1 -> 4
                else -> 3
            }
            overlayView.showBounceLines = maxBounces > 1
            btn.text = "Pantul: ${maxBounces}x"
        }

        val btnFrame = makeChip("Meja: ON", "#00897B") { btn ->
            overlayView.showTableFrame = !overlayView.showTableFrame
            btn.text = if (overlayView.showTableFrame) "Meja: ON" else "Meja: OFF"
            (btn.background as GradientDrawable).setColor(
                Color.parseColor(if (overlayView.showTableFrame) "#00897B" else "#455A64")
            )
            overlayView.postInvalidate()
        }

        val btnCalibMinus = makeChip("Meja -", "#546E7A") {
            FrameDetector.offsetLeft += 4f
            FrameDetector.offsetRight -= 4f
            FrameDetector.offsetTop += 2f
            FrameDetector.offsetBottom -= 2f
        }

        val btnCalibPlus = makeChip("Meja +", "#546E7A") {
            FrameDetector.offsetLeft -= 4f
            FrameDetector.offsetRight += 4f
            FrameDetector.offsetTop -= 2f
            FrameDetector.offsetBottom += 2f
        }

        val btnHide = makeChip("Hide ◀", "#D32F2F") {
            isMenuExpanded = false
            menuPanel.visibility = View.GONE
        }

        menuPanel.addView(btnAim)
        menuPanel.addView(btnBounce)
        menuPanel.addView(btnFrame)
        menuPanel.addView(btnCalibMinus)
        menuPanel.addView(btnCalibPlus)
        menuPanel.addView(btnHide)

        floatingDock.addView(toggleIconBtn)
        floatingDock.addView(menuPanel)

        val dockParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            getOverlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(42)
        }

        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        toggleIconBtn.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = dockParams.x
                    initialY = dockParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    dockParams.x = initialX + (event.rawX - touchX).toInt()
                    dockParams.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(floatingDock, dockParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(event.rawX - touchX) < 12 && abs(event.rawY - touchY) < 12) {
                        isMenuExpanded = !isMenuExpanded
                        menuPanel.visibility = if (isMenuExpanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(floatingDock, dockParams)
    }

    private fun startScreenCapture() {
        val metrics = resources.displayMetrics
        imageReader = ImageReader.newInstance(metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "PoolAimTracker",
            metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, mainHandler
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (isTrackingEnabled) processFrame(image)
            } finally {
                image.close()
            }
        }, mainHandler)
    }

    private fun processFrame(image: android.media.Image) {
        val plane = image.planes[0]
        val rowPadding = plane.rowStride - plane.pixelStride * image.width
        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / plane.pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(plane.buffer)

        val detectedTable = FrameDetector.detectTableBounds(bitmap)
        val physics = PhysicsEngine(detectedTable)
        val balls = FrameDetector.detectBalls(bitmap, detectedTable)
        val cueBall = balls.firstOrNull { it.isCueBall }
        val aimAngle = if (cueBall != null) FrameDetector.detectGameAimLineAngle(bitmap, cueBall) else null

        if (cueBall != null && aimAngle != null) {
            val paths = physics.calculateShot(
                cueBall,
                aimAngle,
                balls,
                maxCueBounces = maxBounces,
                maxTargetBounces = maxBounces
            )
            overlayView.tableRect = detectedTable
            overlayView.pocketPositions = physics.getPockets()
            overlayView.trajectories = paths
            overlayView.postInvalidate()
        }
        bitmap.recycle()
    }

    private fun startForegroundNotification() {
        val channelId = "pool_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Pool Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("Pool Aim Assist Aktif")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        startForeground(101, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        virtualDisplay?.release()
        mediaProjection?.stop()
        if (::overlayView.isInitialized) windowManager.removeView(overlayView)
        if (::floatingDock.isInitialized) windowManager.removeView(floatingDock)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
