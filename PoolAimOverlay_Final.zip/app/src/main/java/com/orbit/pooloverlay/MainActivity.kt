package com.orbit.pooloverlay

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val REQ_OVERLAY = 1001
    private val REQ_CAPTURE = 1002

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0D1117"))
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = "8 BALL POOL — AIM OVERLAY"
            setTextColor(Color.parseColor("#00E676"))
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Overlay transparan 100% + Auto-Track Stik & Pantulan Multi-Ban.\nTekan tombol di bawah, izinkan tampilan di atas aplikasi & rekam layar, lalu buka 8 Ball Pool ori."
            setTextColor(Color.parseColor("#9BA3AF"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 36)
        }

        val btnBg = GradientDrawable().apply {
            cornerRadius = 24f
            setColor(Color.parseColor("#00C853"))
        }

        val btnStart = Button(this).apply {
            text = "AKTIFKAN OVERLAY & BUKA GAME"
            setTextColor(Color.BLACK)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            background = btnBg
            setPadding(48, 28, 48, 28)
            setOnClickListener { checkPermissionsAndStart() }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(btnStart)
        setContentView(root)
    }

    private fun checkPermissionsAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY)
        } else {
            requestScreenCapture()
        }
    }

    private fun requestScreenCapture() {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            requestScreenCapture()
        } else if (requestCode == REQ_CAPTURE && resultCode == Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayTrackingService::class.java).apply {
                putExtra("RESULT_CODE", resultCode)
                putExtra("DATA", data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            val gameIntent = packageManager.getLaunchIntentForPackage("com.miniclip.eightballpool")
            if (gameIntent != null) {
                startActivity(gameIntent)
            } else {
                moveTaskToBack(true)
            }
        }
    }
}
